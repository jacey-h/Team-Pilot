#include "datacontroller.h"
#include <CommonAPI/CommonAPI.hpp>
#include <QtQuick>
#include "helloworldstubimpl.h"

DataController::DataController(QObject *parent) :
    QObject(parent),speed(0),rpm(0),temperature(0),humidity(0),battery(0),
    timer(std::make_shared<QTimer>())
{
    std::shared_ptr<CommonAPI::Runtime> runtime = CommonAPI::Runtime::get();

    myService = std::make_shared<HelloWorldStubImpl>();

    runtime->registerService("local", "test", myService);
    std::cout << "Successfully Registered Service!" << std::endl;

    connect(timer.get(),SIGNAL(timeout()),this,SLOT(updateFunc()));
    timer->setInterval(1000);
    timer->start();

}

int DataController::getSpeed() const
{
    return speed;
}

void DataController::setSpeed(int value)
{
    if(speed == value|| value >= 180)
        return;
    speed = value;
    emit speedChanged();
}

int DataController::getRpm() const
{
    return rpm;
}

void DataController::setRpm(int value)
{
    if(rpm == value)
        return;
    rpm = value;
    emit rpmChanged();
}

int DataController::getTemperature() const
{
    return temperature;
}

void DataController::setTemperature(int value)
{
    if(temperature == value || value >= 50 || value < 0)
        return;
    temperature = value;
    emit tempChanged();
}

int DataController::getHumidity() const
{
    return humidity;
}

void DataController::setHumidity(int value)
{
    if(humidity == value|| value >= 100)
        return;
    humidity = value;
    emit humChanged();
}

int DataController::getBattery() const
{
    return battery;
}

void DataController::setBattery(int value)
{
    if(battery == value|| value >= 100|| value < 0)
        return;
    battery = value/5;
    emit batteryChanged();
}

void DataController::updateFunc()
{
    setSpeed(myService.get()->getCode1());
    setRpm(myService.get()->getCode2());
    setTemperature(myService.get()->getCode3());
    setHumidity(myService.get()->getCode4());
    setBattery(myService.get()->getCode5());

}
