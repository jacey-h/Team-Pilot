#!/bin/sh

start() {
    /usr/share/examples/opengl/paintedwindow/paintedwindow   

}

stop() {
    /usr/bin/killall QtDemo
}

case "$1" in
    start|restart)
        echo "Starting QtDemo"
        stop
        start
        ;;
    stop)
        echo "Stopping QtDemo"
        stop
        ;;
esac
